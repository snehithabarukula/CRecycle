const express = require('express');
const mysql = require('mysql2');
const app = express();
const port = 3000;
const cors = require('cors'); // Add CORS support
const query = `INSERT INTO product (barcode, cust_id, subcategory_id, size, chain_id, voucher_code)
               VALUES (?, ?, (SELECT subcategory_id FROM product_subcategory WHERE subcategory_name = ?), ?, ?, ?)`;


const db = mysql.createPool({
    connectionLimit: 10,
    host: '127.0.0.1',
    port: '3306',
    user: 'root',
    password: 'root',
    database: 'smartdisposal',
    waitForConnections: true,
    queueLimit: 0,
});

app.use(express.json());
app.use(express.static('public'));
app.use(cors()); // Enable CORS for all routes

app.get('/getProductCategories', (req, res) => {
    db.query('SELECT DISTINCT category_name FROM product_category', (error, results) => {
        if (error) {
            console.error('Error fetching product categories:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            const categories = results.map(result => {
                return {
                    id: result.category_name,
                    name: result.category_name
                };
            });
            res.json(categories);
        }
    });
});

app.get('/getProductDetails', (req, res) => {
    db.query('SELECT DISTINCT subcategory_id, subcategory_name FROM product_subcategory', (error, results) => {
        if (error) {
            console.error('Error fetching product details:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            const details = results.map(result => {
                return {
                    id: result.subcategory_name,
                    name: result.subcategory_name
                };
            });
            res.json(details);
        }
    });
});

app.get('/productSize', (req, res) => {
    db.query('SELECT DISTINCT size FROM product_size', (error, results) => {
        if (error) {
            console.error('Error fetching product sizes or quantities:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            const sizesOrQuantities = results.map(result => {
                return {
                    id: result.size,
                    name: result.size
                };
            });
            res.json(sizesOrQuantities);
        }
    });
});

app.get('/getProductDetailsByCategory', (req, res) => {
    const selectedCategory = req.query.category;
    const query = 'SELECT DISTINCT subcategory_name FROM product_subcategory WHERE category_id = ?';
    db.query(query, [selectedCategory], (error, results) => {
        if (error) {
            console.error('Error fetching product details by category:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            const productDetails = results.map(result => {
                return {
                    id: result.subcategory_name, 
                    name: result.subcategory_name 
                };
            });
            res.json(productDetails);
        }
    });
});


app.post('/submitForm', (req, res) => {
    const formData = req.body;

    db.query('INSERT INTO store SET ?', formData, (error, results) => {
        if (error) {
            console.error('Error inserting data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            console.log('Data inserted successfully');
            res.json({ success: true });
        }
    });
});

app.post('/submitCustomerForm', (req, res) => {
    const formData = req.body;

    db.query('INSERT INTO customer SET ?', formData, (error, results) => {
        if (error) {
            console.error('Error inserting data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            console.log('Data inserted into customer table successfully');
            res.json({ success: true });
        }
    });
});

app.post('/submitExCustomerForm', (req, res) => {
    const formData = req.body;

    var voucher_code = formData.voucher_code;
    if(voucher_code==''){
        voucher_code =null;
    }

    db.query(query, [
        formData.barcode,
        formData.cust_id, 
        formData.subcategory_id, 
        formData.size,
        formData.chain_id,
        voucher_code 
    ], (error, results) => {
        if (error) {
            console.error('Error inserting data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            res.json({ success: true });
        }
    });
}); 

app.post('/submitdepositForm', (req, res) => {
    const formData = req.body;

    db.query('INSERT INTO deposit (bin_id, product_id, registered_by) VALUES (?, ?, ?)', [formData.bin_id, formData.product_id, formData.registered_by], (error, results) => {
        if (error) {
            console.error('Error inserting data into deposit table:', error); 
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            console.log('Data inserted into deposit table successfully'); 
            res.json({ success: true });
        }
    });
});


app.get('/calculatePriceAndPoints', (req, res) => {
    const barcode = req.query.barcode;
    db.query('SELECT price, points FROM product_bill WHERE barcode = ?', [barcode], (error, results) => {
        if (error) {
            console.error('Error fetching data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            if (results.length > 0) {
                const data = results[0];
                res.json({ price: data.price, points: data.points });
            } else {
                res.json({ price: 0, points: 0 });
            }
        }
    });
});

app.post('/storeLogin', (req, res) => {
    const { store_username, password_created } = req.body;

    // Query the database to check if the credentials are valid
    db.query('SELECT * FROM store WHERE store_username = ? AND password_created = ?', [store_username, password_created], (error, results) => {
        if (error) {
            console.error('Error querying data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            if (results.length > 0) {
                res.json({ success: true });
            } else {
                res.json({ success: false, error: 'Incorrect credentials' });
            }
        }
    });
});

app.post('/customerLogin', (req, res) => {
    console.log('Received a customer login request:', req.body);
    const { customer_username, password_created } = req.body;

    // Query the database to check if the credentials are valid
    db.query('SELECT * FROM customer WHERE customer_username = ? AND password_created = ?', [customer_username, password_created], (error, results) => {
        if (error) {
            console.error('Error querying data:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        } else {
            if (results.length > 0) {
                res.json({ success: true });
            } else {
                res.json({ success: false, error: 'Incorrect credentials' });
            }
        }
    });
});

app.post('/submitVoucherForm', (req, res) => {
    const formData = req.body;

    // Fetch required points for the voucher
    db.query('SELECT points FROM voucher WHERE voucher_id = ?', [formData.voucher_id], (error, voucherResults) => {
        if (error) {
            console.error('Error fetching voucher data:', error);
            return res.status(500).json({ error: 'Internal Server Error' });
        }
        if (voucherResults.length === 0) {
            return res.status(404).json({ error: 'Voucher not found' });
        }

        const pointsRequired = voucherResults[0].points;

        // Fetch customer's current points
        db.query('SELECT points FROM customer_reward_points WHERE cust_id = ?', [formData.cust_id], (error, customerResults) => {
            if (error) {
                console.error('Error fetching customer data:', error);
                return res.status(500).json({ error: 'Internal Server Error' });
            }
            if (customerResults.length === 0) {
                return res.status(404).json({ error: 'Customer not found' });
            }

            const customerPoints = customerResults[0].points;
            

            // Check if the customer has enough points
            if (customerPoints < pointsRequired) {
                return res.status(400).json({ error: 'Insufficient points' });
            }

            // Proceed with voucher redemption
            db.query('INSERT INTO customer_earns_voucher(cust_id, voucher_id, earn_date) VALUES (?,?,CURDATE())', [formData.cust_id, formData.voucher_id], (error, results) => {
                if (error) {
                    console.error('Error inserting data:', error);
                    return res.status(500).json({ error: 'Internal Server Error' });
                }
                //Get the voucher code
                db.query('SELECT voucher_code FROM customer_earns_voucher WHERE cust_id= ? AND voucher_id=?', [formData.cust_id, formData.voucher_id], (error, vouchResults) => {
                    if (error) {
                        console.error('Error getting voucher code:', error);
                        return res.status(500).json({ error: 'Internal Server Error' });
                    }
                    const voucher_code = vouchResults[0].voucher_code
                    const message = 'Voucher redeemed successfully. Your voucher code:'+ voucher_code;
                    //Get the voucher code
                    res.json({ message: message});
                });
            });
        });
    });
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
