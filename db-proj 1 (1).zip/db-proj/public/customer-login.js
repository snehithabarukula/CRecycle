document.addEventListener('DOMContentLoaded', function () {
    // Attach event listener to the form on page load
    var loginForm = document.getElementById('customer-loginForm');
    loginForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission

        // Get the entered username and password
        var customer_username = document.getElementById('username').value;
        var password_created = document.getElementById('password').value;

        // Validate the form data if needed

        // Send the login data to the server for verification
        sendDataToServer({ customer_username, password_created });
    });
});

function sendDataToServer(data) {
    // Use Fetch API to send login data to the server
    fetch('/customerLogin', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(result => {
        var customer_username = document.getElementById('username').value;
        // Handle the server response
        console.log(result);
        if (result.success) {
            // Redirect to the customer dashboard or any other page on successful login
            window.location.href = `user.html?customer_username=${customer_username}`;
 
        } else {
            // Display an error message for incorrect credentials
            alert('Incorrect credentials. Please try again.');
        }
    })
    .catch(error => {
        // Handle errors
        console.error('Error:', error.message);
        alert('Error during login. Please try again.');
    });
}