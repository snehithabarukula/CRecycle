function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

var barcodeInput = document.getElementById('barcode');
var pointsInput = document.getElementById('points');
var priceInput = document.getElementById('price');

if (barcodeInput) {
    var barcodeValue = getParameterByName('barcode');
    barcodeInput.value = barcodeValue;

    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/calculatePriceAndPoints?barcode=' + barcodeValue, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var response = JSON.parse(xhr.responseText);
            pointsInput.value = response.points;
            priceInput.value = response.price;
        }
    };
    xhr.send();
}