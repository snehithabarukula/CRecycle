function submitDepositForm() {
    var bin_id = document.getElementById('bin_id').value;
    var product_id = document.getElementById('product_id').value;
    var registered_by = document.getElementById('registered_by').value;

    send_depositDataToServer({
        bin_id: bin_id,
        product_id: product_id,
        registered_by: registered_by
    }, '/submitdepositForm');
}

function send_depositDataToServer(data, endpoint) {
    fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(result => {
        console.log(result);
        alert('Deposit details submitted successfully!');
    })
    .catch(error => {
        console.error('Error:', error.message);
        alert('Error submitting deposit details. Please try again.');
    });
}
