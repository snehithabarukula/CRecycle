function registerDeposit() {
    window.location.href = "deposit.html"; // Redirect to deposit.html
}

// Function to handle the "Place an Order" button click
function placeOrder() {
    window.location.href = "storeDashboard.html"; // Redirect to storeDashboard.html 
}

// Add event listeners to the buttons
document.addEventListener("DOMContentLoaded", function () {
    const registerButton = document.querySelector("#registerDepositBtn");
    const orderButton = document.querySelector("#placeOrderBtn");

    if (registerButton) {
        registerButton.addEventListener("click", registerDeposit);
    }

    if (orderButton) {
        orderButton.addEventListener("click", placeOrder);
    }
});
