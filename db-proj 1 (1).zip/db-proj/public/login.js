document.getElementById('loginForm').addEventListener('submit', function (e) {
    e.preventDefault();
});

document.getElementById('signupForm').addEventListener('submit', function (e) {
    e.preventDefault();
});

// Function to open the company signin page
function loginAsCustomer() {
    // Redirect to the customer login page
    window.location.href = 'customer-login.html';
}

function loginAsStore() {
    // Redirect to the store login page
    window.location.href = 'store-login.html';
}

function signInAsCompany() {
    window.location.href = 'store.html';
}

function SignInAsCustomer() {
    window.location.href = 'customer.html';
}


// Click event listener to the "Sign in as a Company" button
document.getElementById('signInAsCompanyButton').addEventListener('click', signInAsCompany);

