// store.js
function submitCompanySignUpForm() {
    var chain_id = document.getElementById('chain_id').value;
    var store_username = document.getElementById('store_username').value;
    var password_created = document.getElementById('password_created').value; // Change to match your HTML
    var street_no = document.getElementById('street_no').value;
    var street_name = document.getElementById('street_name').value;
    var town = document.getElementById('town').value;
    var zipcode = document.getElementById('zipcode').value;

    // Validate the form data if needed

    // Send the data to the server for processing
    sendDataToServer({
        chain_id: chain_id,
        store_username: store_username,
        password_created: password_created,
        street_no: street_no,
        street_name: street_name,
        town: town,
        zipcode: zipcode
    });
}

function sendDataToServer(data) {
    // Use Fetch API to send data to the server
    fetch('/submitForm', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(result => {
        console.log(result);
        alert('Company account created successfully!');
    })
    .catch(error => {
        // Handle errors
        console.error('Error:', error.message);
        alert('Error creating company account. Please try again.');
    });
}