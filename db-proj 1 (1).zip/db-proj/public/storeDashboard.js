document.addEventListener('DOMContentLoaded', function () {

    // Fetch product categories, details, sizes/quantities from the server and populate the drop-downs
    fetchAndPopulateDropdown('/getProductCategories', 'productCategory');
    fetchAndPopulateDropdown('/getProductDetails', 'productDetails');
    fetchAndPopulateDropdown('/productSize', 'productSize');

    fetchAndPopulateProductDetails();


    // Attach submit event listeners to forms
    var newCustomerForm = document.getElementById('newCustomerForm');
    var billingForm = document.getElementById('billingForm');

    newCustomerForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission
        var formData = new FormData(newCustomerForm);
        submitCustomerSignUpForm('/submitCustomerForm', formData, function () {
        });
    });

    billingForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission
        var formData = new FormData(billingForm);
        sendFormDataToServer('/submitExCustomerForm', formData);
        
    });

    // Initially, show both sets of form fields
    toggleCustomerFields();
    
    document.getElementById('productCategory').addEventListener('change', function() {
        const selectedCategory = this.value;
        fetchAndPopulateDropdown(`/getProductDetailsByCategory?category=${encodeURIComponent(selectedCategory)}`, 'productDetails');
    });
    
});


function submitCustomerSignUpForm() {
    var phone_number = document.getElementById('phone_number').value;
    var customer_username = document.getElementById('customer_username').value;
    var password_created = document.getElementById('password_created').value;
    var street_no = document.getElementById('street_no').value;
    var street_name = document.getElementById('street_name').value;
    var state = document.getElementById('state').value;
    var town = document.getElementById('town').value;
    var zipcode = document.getElementById('zipcode').value;

    sendDataToServer({
        phone_number: phone_number,
        customer_username: customer_username,
        password_created: password_created,
        street_no: street_no,
        street_name: street_name,
        state: state,
        town: town,
        zipcode: zipcode
    }, '/submitCustomerForm');
}

function sendDataToServer(data, endpoint) {
    fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(result => {
        console.log(result);
        alert('Customer account created successfully!');
    })
    .catch(error => {
        console.error('Error:', error.message);
        alert('Error creating customer account. Please try again.');
    });
}



function submitExCustomerSignUpForm() {
    var barcode = document.getElementById('barcode').value;
    var custId = document.getElementById('ph_number').value; 
    var productDetailsId = document.getElementById('productDetails').value; 
    var productSize = document.getElementById('productSize').value;
    var chainId = document.getElementById('chain_id').value;
    var voucher_code = document.getElementById('voucher_code').value;


    var billingData = {
        barcode: barcode,
        cust_id: custId,
        subcategory_id: productDetailsId, 
        size: productSize,
        chain_id: chainId,
        voucher_code: voucher_code
    };

    sendExDataToServer(billingData, '/submitExCustomerForm');
}



function sendExDataToServer(data, endpoint) {
    fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(result => {
        var customer_username = document.getElementById('barcode').value;
        console.log(result);
        if (result.success) {
            alert('Billing data submitted successfully!');
            window.location.href = `product_bill.html?barcode=${customer_username}`;
        } 
    })
    .catch(error => {
        console.error('Error:', error.message);
        alert('Error submitting billing data. Please try again.');
    });
}

document.getElementById('ExCustomerForm').addEventListener('submit', function(event) {
    event.preventDefault(); 
    submitExCustomerSignUpForm();
});


// Function to fetch data from the server and populate a dropdown
function fetchAndPopulateDropdown(endpoint, dropdownId) {
    fetch(endpoint)
        .then(response => response.json())
        .then(data => {
            populateDropDown(dropdownId, data);
        })
        .catch(error => console.error('Error:', error));
}

// Function to populate a dropdown with options
function populateDropDown(dropDownId, options) {
    var dropDown = document.getElementById(dropDownId);
    dropDown.innerHTML = '';

    options.forEach(function (option) {
        var optionElement = document.createElement('option');
        optionElement.value = option.id;
        optionElement.textContent = option.name;
        dropDown.appendChild(optionElement);
    });
}


function fetchAndPopulateProductDetails() {
    fetch('/getProductDetails')
        .then(response => response.json())
        .then(data => {
            populateProductDetailsDropdown(data);
        })
        .catch(error => console.error('Error:', error));
}

function populateProductDetailsDropdown(data) {
    var dropdown = document.getElementById('productDetails');
    dropdown.innerHTML = ''; 

    data.forEach(function (item) {
        var optionElement = document.createElement('option');
        optionElement.value = item.id; // subcategory_id
        optionElement.textContent = item.name; // subcategory_name
        dropdown.appendChild(optionElement);
    });
}

function toggleCustomerFields() {
    var newCustomerFields = document.getElementById('newCustomerFields');
    var existingCustomerFields = document.getElementById('existingCustomerFields');
    var newCustomerCheckbox = document.getElementById('newCustomer');
    var existingCustomerCheckbox = document.getElementById('existingCustomer');

    if (newCustomerCheckbox.checked) {
        newCustomerFields.style.display = 'block';
        existingCustomerFields.style.display = 'none';
    } else if (existingCustomerCheckbox.checked) {
        newCustomerFields.style.display = 'none';
        existingCustomerFields.style.display = 'block';
    } else {
        newCustomerFields.style.display = 'none';
        existingCustomerFields.style.display = 'none';
    }
}
