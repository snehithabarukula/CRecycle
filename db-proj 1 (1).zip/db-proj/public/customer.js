function submitCustomerSignUpForm() {
    var phone_number = document.getElementById('phone_number').value;
    var customer_username = document.getElementById('customer_username').value;
    var password_created = document.getElementById('password_created').value;
    var street_no = document.getElementById('street_no').value;
    var street_name = document.getElementById('street_name').value;
    var state = document.getElementById('state').value;
    var town = document.getElementById('town').value;
    var zipcode = document.getElementById('zipcode').value;

    sendDataToServer({
        phone_number: phone_number,
        customer_username: customer_username,
        password_created: password_created,
        street_no: street_no,
        street_name: street_name,
        state: state,
        town: town,
        zipcode: zipcode
    }, '/submitCustomerForm');
}

function sendDataToServer(data, endpoint) {
    fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(result => {
        console.log(result);
        alert('Customer account created successfully!');
    })
    .catch(error => {
        console.error('Error:', error.message);
        alert('Error creating customer account. Please try again.');
    });
}
