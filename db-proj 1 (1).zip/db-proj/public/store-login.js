document.addEventListener('DOMContentLoaded', function () {
    // Attach event listener to the form on page load
    var loginForm = document.getElementById('loginForm');
    loginForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the default form submission

        // Get the entered username and password
        var store_username = document.getElementById('username').value;
        var password_created = document.getElementById('password').value;

        sendDataToServer({ store_username, password_created });
    });
});

function sendDataToServer(data) {
    // Use Fetch API to send login data to the server
    fetch('/storeLogin', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(result => {
        // Handle the server response
        console.log(result);
        if (result.success) {
            // Redirect to the store dashboard or any other page on successful login
            window.location.href = 'storeBilling.html';
        } else {
            // Display an error message for incorrect credentials
            alert('Incorrect credentials. Please try again.');
        }
    })
    .catch(error => {
        // Handle errors
        console.error('Error:', error.message);
        alert('Error during login. Please try again.');
    });
}
