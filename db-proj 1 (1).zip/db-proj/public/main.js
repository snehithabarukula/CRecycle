// Interactive features
const button = document.querySelector('.btn');
button.addEventListener('click', function() {
    this.textContent = 'Thanks for clicking!';
    alert('You clicked the button!');
});
