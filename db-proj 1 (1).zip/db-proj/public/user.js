function submitCustomerVoucherForm() {
  var phone_number = document.getElementById('phone_number').value;
  var voucher_id = document.getElementById('voucher_id').value;
  const current_date = new Date().toISOString().slice(0, 10);

  sendDataToServerVoucher({
      cust_id: phone_number,
      voucher_id: voucher_id,
      earn_date: current_date
  }, '/submitVoucherForm');
}

function sendDataToServerVoucher(data, endpoint) {
  fetch(endpoint, {
      method: 'POST',
      headers: {
          'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
  })
  .then(response => {
      if (!response.ok) {
          throw new Error('Network response was not ok');
      }
      return response.json();
  })
  .then(result => {
    console.log('b4');
      console.log(result);
      console.log('a4');
      alert(result.message);
      
  })
  .catch(error => {
      console.error('Error:', error.message);
      alert('You do not have sufficient points.');
  });
}
